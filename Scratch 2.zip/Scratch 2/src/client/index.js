//import { checkForName } from './js/nameChecker'
//import { checkForName } from './js/nameChecker'
//alert('new stated')
import { handleSubmit } from './js/app'

import './styles/main.scss'
import "./js/app.js";

export {
   handleSubmit
}