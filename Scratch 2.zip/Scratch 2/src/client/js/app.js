function handleSubmit(event) {
    event.preventDefault()

}

/* Global Variables */
//alert('loaded')
console.log('start')
var y =0;
var country;
var state;
var xcity;
var xcode;
var population;
var sunrise;
var time_zone
var temp;
var precipation;
var snow;
var imageurl;

document.getElementById("button2").addEventListener("mousedown", function(event) {
    //alert('captured');
          fetchcity();
        fetchweather();
          if (event.button == 2) // Right Click
            event.stopPropagation();
        });
  
  
 
const baseURL = 'http://api.geonames.org/searchJSON?q=';
const apicontd = '&maxRows=1&username=kempex';

const fetchcity = async () => {
    const vcity = document.getElementById('fname').value;
    try {
        const res = await fetch( baseURL+ vcity+ apicontd);
        if (!res.ok) {
            throw new Error(res.status);
        }
        const data = await res.json();
        console.log(data.geonames[0].name);
        console.log(data.geonames[0].countryName);
       country= data.geonames[0].countryName
       state= data.geonames[0].adminName1
       xcity= data.geonames[0].name
       xcode= data.geonames[0].countryCode
       population= data.geonames[0]. population
    } catch (error) {
        //console.log(error);
    }
}

const weatherbaseURL = 'https://api.weatherbit.io/v2.0/current?city=';
const weatherapicontd = '&key=a37df19c9c7843d6a64694b9e734f968';
const fetchweather = async () => {
    const vcity = document.getElementById('fname').value;
    try {
        const res = await fetch( weatherbaseURL+ vcity+ weatherapicontd);
        if (!res.ok) {
            throw new Error(res.status);
        }
        const data = await res.json();
  sunrise= data.data[0].sunrise;
    time_zone= data.data[0].timezone;
       temp= data.data[0].app_temp;
       precipation= data.data[0].precip;
       snow= data.data[0].snow;
       fetchpixabay();
    } catch (error) {
        //console.log(error);
    }
}


const pixabaybaseURL = 'https://pixabay.com/api/?key=16308094-a98147687305f2b3bec29ffba&q=';
const pixabayapicontd = '&image_type=photo&pretty=true';
const fetchpixabay = async () => {
    const vcity = country;
    try {
        const res = await fetch( pixabaybaseURL+ vcity+ pixabayapicontd);
        if (!res.ok) {
            throw new Error(res.status);
        }
        const data = await res.json();
       imageurl= data.hits[0].webformatURL;
       imageurl2=(data.hits[0].largeImageURL);
        harvest();
    } catch (error) {
        //console.log(error);
    }
};

function harvest(){
    y=y+1;
    document.getElementById("footer").remove();
    
        var data = '<div class="toolbar">'+
                
'<div id="bg2">' +
                '<button onclick="myFunction()" id = "button2">Remove Trip</i></button>'+
                '<label for="lbb" id = lbb> Country Code : ' + xcode +'</label>'+
                '<label for="lbb" id = lbb> Country : ' + country +'</label>'+
                '<label for="lbb2" id = lbb> State : ' + state +'</label>'+
                '<label for="lbb2" id = lbb> City : ' + xcity +'</label>'+
                '<label for="lbb2" id = lbb> Population : ' + population +'</label>'+
                '<br></br>' +
                '<label for="lbb2" id = lbb> Sunrise : ' + sunrise +'</label>'+
                '<label for="lbb2" id = lbb> Time Zone : ' + time_zone +'</label>'+
                '<label for="lbb2" id = lbb> Temperature : ' + temp +' C</label>'+
                '<label for="lbb2" id = lbb> Precipation : ' + precipation +'</label>'+
                '<label for="lbb2" id = lbb> Snow : ' + snow +'</label>'+
                
'<br></br>' +
    '<br></br>'+
    '<br></br>'+
'</div>' +
            '</div>';
          var div = document.createElement("div");
          div.id = 'bgk'+y;
    div.innerHTML = data;
    document.getElementById('results').appendChild(div);
        const IMAGE_URLS = imageurl2;
        document.body.appendChild(div);
        document.getElementById("bgk" + y).style.backgroundImage="url('"+IMAGE_URLS+"')";
       document.getElementById("bgk" + y).style.height = "500px";
       document.getElementById("bgk" + y).style.width = "900px";
       document.getElementById("bgk" + y).style.left="200px";
       
    //add footer to document
    var btn = document.createElement("footer");
       btn.id='footer'
    btn.innerHTML = '<a href="#" class="fa fa-facebook"></a>';                   // Insert text
    document.body.appendChild(btn);               // Append <button> to <body>
    }

   
    